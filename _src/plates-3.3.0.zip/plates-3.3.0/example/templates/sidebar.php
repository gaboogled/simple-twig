<ul>
    <li><a href="#link">Example sidebar link</a></li>
    <li><a href="#link">Example sidebar link</a></li>
    <li><a href="#link">Example sidebar link</a></li>
    <li><a href="#link">Example sidebar link</a></li>
</ul>